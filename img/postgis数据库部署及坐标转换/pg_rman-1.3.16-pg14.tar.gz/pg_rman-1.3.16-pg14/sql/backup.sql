\! bash sql/backup.sh

