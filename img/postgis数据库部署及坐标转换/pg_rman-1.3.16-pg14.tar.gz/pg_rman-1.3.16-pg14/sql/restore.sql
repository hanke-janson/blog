\! bash sql/restore.sh

