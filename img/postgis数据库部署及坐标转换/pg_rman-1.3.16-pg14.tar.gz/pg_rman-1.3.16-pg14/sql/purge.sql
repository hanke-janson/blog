\! bash sql/purge.sh
