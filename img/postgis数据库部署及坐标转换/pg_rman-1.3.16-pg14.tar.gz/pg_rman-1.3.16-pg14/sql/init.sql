\! bash sql/init.sh
